import React from 'react';

export default function SkillMomsSite() {
  return (
    <div style={{fontFamily:'sans-serif', padding:'2rem'}}>
      <h1>🎉 SkillMoms UG Website</h1>
      <p>Deployed successfully with Vercel + Vite + React.</p>
    </div>
  );
}
